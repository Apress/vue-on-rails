require 'test_helper'

class PlayerTest < ActiveSupport::TestCase

end

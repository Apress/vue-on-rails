<template>
  <div id="app">
    <p>{{ message }}</p>
  </div>
</template>

<script src="./quotes.js"></script>
<style scoped src="./quotes.css"></style>

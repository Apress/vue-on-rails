module.exports = {
  lintOnSave: true
}
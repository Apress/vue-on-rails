<template>
  <div id="app">
    <tabs>
      <tab name="First tab">
          First tab content
      </tab>
      <tab name="Second tab">
          Second tab content
      </tab>
      <tab name="Third tab">
          Third tab content
      </tab>
    </tabs>
  </div>
</template>

<script src="./tab_component.js"></script>
<style src="./tab_component.css"></style>

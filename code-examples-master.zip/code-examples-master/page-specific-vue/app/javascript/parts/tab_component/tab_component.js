export default {
  data: function() {
    return {
      message: "Hello tab_component!"
    };
  },
  methods: {
    
  }
};

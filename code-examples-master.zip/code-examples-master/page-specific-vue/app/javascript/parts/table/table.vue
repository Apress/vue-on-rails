<template>
  <div id="app">
    <br>
    <vue-good-table
      :columns="columns"
      :rows="rows"/>
  </div>
</template>

<script src="./table.js"></script>
<style scoped src="./table.css"></style>
